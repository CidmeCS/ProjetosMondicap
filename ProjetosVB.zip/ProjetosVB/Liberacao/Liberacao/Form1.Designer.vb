﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmLiberacao
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblTitulo = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.ShapeContainer1 = New Microsoft.VisualBasic.PowerPacks.ShapeContainer()
        Me.LineShape2 = New Microsoft.VisualBasic.PowerPacks.LineShape()
        Me.LineShape1 = New Microsoft.VisualBasic.PowerPacks.LineShape()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.txtRealizadopor = New System.Windows.Forms.TextBox()
        Me.lblDataverificacao = New System.Windows.Forms.Label()
        Me.lblHoraverificacao = New System.Windows.Forms.Label()
        Me.txtOutro = New System.Windows.Forms.TextBox()
        Me.txtOP = New System.Windows.Forms.TextBox()
        Me.lblDataEnvio = New System.Windows.Forms.Label()
        Me.lblProduto = New System.Windows.Forms.Label()
        Me.lblCodigo = New System.Windows.Forms.Label()
        Me.lblHoraEnvio = New System.Windows.Forms.Label()
        Me.txtCor = New System.Windows.Forms.TextBox()
        Me.txtCaixa = New System.Windows.Forms.TextBox()
        Me.txtMaquina = New System.Windows.Forms.TextBox()
        Me.txtObservacao = New System.Windows.Forms.TextBox()
        Me.txtEnviado = New System.Windows.Forms.TextBox()
        Me.rbLiberado = New System.Windows.Forms.RadioButton()
        Me.rbNLiberada = New System.Windows.Forms.RadioButton()
        Me.rbIniProducao = New System.Windows.Forms.RadioButton()
        Me.rbMolde = New System.Windows.Forms.RadioButton()
        Me.rbTrocaOP = New System.Windows.Forms.RadioButton()
        Me.rbOutro = New System.Windows.Forms.RadioButton()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.txtStatus = New System.Windows.Forms.TextBox()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.lblMotivo = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'lblTitulo
        '
        Me.lblTitulo.AutoSize = True
        Me.lblTitulo.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTitulo.Location = New System.Drawing.Point(392, 22)
        Me.lblTitulo.Name = "lblTitulo"
        Me.lblTitulo.Size = New System.Drawing.Size(102, 24)
        Me.lblTitulo.TabIndex = 0
        Me.lblTitulo.Text = "Liberação"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(21, 98)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(193, 13)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "VERIFICAÇÃO APÓS TROCA DE COR"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(29, 130)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(76, 13)
        Me.Label2.TabIndex = 200
        Me.Label2.Text = "Verificado Por:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(29, 150)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(33, 13)
        Me.Label3.TabIndex = 399
        Me.Label3.Text = "Data:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(29, 170)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(33, 13)
        Me.Label4.TabIndex = 477
        Me.Label4.Text = "Hora:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(29, 190)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(99, 13)
        Me.Label5.TabIndex = 588
        Me.Label5.Text = "Status da Máquina:"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(561, 60)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(196, 13)
        Me.Label8.TabIndex = 8
        Me.Label8.Text = "ENVIO DE AMOSTRAS À QUALIDADE"
        '
        'ShapeContainer1
        '
        Me.ShapeContainer1.Location = New System.Drawing.Point(0, 0)
        Me.ShapeContainer1.Margin = New System.Windows.Forms.Padding(0)
        Me.ShapeContainer1.Name = "ShapeContainer1"
        Me.ShapeContainer1.Shapes.AddRange(New Microsoft.VisualBasic.PowerPacks.Shape() {Me.LineShape2, Me.LineShape1})
        Me.ShapeContainer1.Size = New System.Drawing.Size(886, 503)
        Me.ShapeContainer1.TabIndex = 9
        Me.ShapeContainer1.TabStop = False
        '
        'LineShape2
        '
        Me.LineShape2.Name = "LineShape2"
        Me.LineShape2.X1 = 770
        Me.LineShape2.X2 = 372
        Me.LineShape2.Y1 = 153
        Me.LineShape2.Y2 = 153
        '
        'LineShape1
        '
        Me.LineShape1.Name = "LineShape1"
        Me.LineShape1.X1 = 344
        Me.LineShape1.X2 = 344
        Me.LineShape1.Y1 = 69
        Me.LineShape1.Y2 = 300
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(29, 230)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(71, 13)
        Me.Label7.TabIndex = 788
        Me.Label7.Text = "Não Liberada"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(29, 210)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(48, 13)
        Me.Label6.TabIndex = 688
        Me.Label6.Text = "Liberada"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(382, 94)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(96, 13)
        Me.Label9.TabIndex = 10
        Me.Label9.Text = "Inicio de Produção"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(411, 119)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(68, 13)
        Me.Label10.TabIndex = 11
        Me.Label10.Text = "Troca de OP"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(539, 94)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(118, 13)
        Me.Label11.TabIndex = 12
        Me.Label11.Text = "Recolocação de Molde"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(539, 119)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(33, 13)
        Me.Label12.TabIndex = 13
        Me.Label12.Text = "Outro"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(382, 199)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(47, 13)
        Me.Label13.TabIndex = 14
        Me.Label13.Text = "Produto:"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(382, 219)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(43, 13)
        Me.Label14.TabIndex = 15
        Me.Label14.Text = "Código:"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(576, 219)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(26, 13)
        Me.Label15.TabIndex = 16
        Me.Label15.Text = "Cor:"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(382, 239)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(51, 13)
        Me.Label16.TabIndex = 17
        Me.Label16.Text = "Máquina:"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(576, 239)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(51, 13)
        Me.Label17.TabIndex = 18
        Me.Label17.Text = "Nº Caixa:"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(382, 179)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(25, 13)
        Me.Label18.TabIndex = 19
        Me.Label18.Text = "OP:"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(630, 170)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(33, 13)
        Me.Label19.TabIndex = 20
        Me.Label19.Text = "Data:"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(382, 259)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(73, 13)
        Me.Label20.TabIndex = 21
        Me.Label20.Text = "Observações:"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(382, 302)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(67, 13)
        Me.Label21.TabIndex = 22
        Me.Label21.Text = "Enviado por:"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(630, 190)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(33, 13)
        Me.Label23.TabIndex = 24
        Me.Label23.Text = "Hora:"
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Button1.Location = New System.Drawing.Point(30, 268)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 36)
        Me.Button1.TabIndex = 1
        Me.Button1.Text = "Nova Liberação"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Button2.Location = New System.Drawing.Point(120, 268)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(75, 36)
        Me.Button2.TabIndex = 26
        Me.Button2.Text = "Alterar Liberação"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Button3.Location = New System.Drawing.Point(210, 268)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(75, 36)
        Me.Button3.TabIndex = 27
        Me.Button3.Text = "Imprimir Liberação"
        Me.Button3.UseVisualStyleBackColor = False
        '
        'txtRealizadopor
        '
        Me.txtRealizadopor.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtRealizadopor.Location = New System.Drawing.Point(144, 123)
        Me.txtRealizadopor.Name = "txtRealizadopor"
        Me.txtRealizadopor.Size = New System.Drawing.Size(165, 20)
        Me.txtRealizadopor.TabIndex = 2
        '
        'lblDataverificacao
        '
        Me.lblDataverificacao.AutoSize = True
        Me.lblDataverificacao.Location = New System.Drawing.Point(141, 150)
        Me.lblDataverificacao.Name = "lblDataverificacao"
        Me.lblDataverificacao.Size = New System.Drawing.Size(11, 13)
        Me.lblDataverificacao.TabIndex = 34
        Me.lblDataverificacao.Text = "*"
        '
        'lblHoraverificacao
        '
        Me.lblHoraverificacao.AutoSize = True
        Me.lblHoraverificacao.Location = New System.Drawing.Point(141, 170)
        Me.lblHoraverificacao.Name = "lblHoraverificacao"
        Me.lblHoraverificacao.Size = New System.Drawing.Size(11, 13)
        Me.lblHoraverificacao.TabIndex = 35
        Me.lblHoraverificacao.Text = "*"
        '
        'txtOutro
        '
        Me.txtOutro.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtOutro.Enabled = False
        Me.txtOutro.Location = New System.Drawing.Point(577, 114)
        Me.txtOutro.MaxLength = 50
        Me.txtOutro.Name = "txtOutro"
        Me.txtOutro.Size = New System.Drawing.Size(186, 20)
        Me.txtOutro.TabIndex = 9
        '
        'txtOP
        '
        Me.txtOP.Location = New System.Drawing.Point(461, 171)
        Me.txtOP.Name = "txtOP"
        Me.txtOP.Size = New System.Drawing.Size(141, 20)
        Me.txtOP.TabIndex = 10
        '
        'lblDataEnvio
        '
        Me.lblDataEnvio.AutoSize = True
        Me.lblDataEnvio.Location = New System.Drawing.Point(669, 170)
        Me.lblDataEnvio.Name = "lblDataEnvio"
        Me.lblDataEnvio.Size = New System.Drawing.Size(11, 13)
        Me.lblDataEnvio.TabIndex = 38
        Me.lblDataEnvio.Text = "*"
        '
        'lblProduto
        '
        Me.lblProduto.AutoSize = True
        Me.lblProduto.Location = New System.Drawing.Point(458, 199)
        Me.lblProduto.Name = "lblProduto"
        Me.lblProduto.Size = New System.Drawing.Size(11, 13)
        Me.lblProduto.TabIndex = 39
        Me.lblProduto.Text = "*"
        '
        'lblCodigo
        '
        Me.lblCodigo.AutoSize = True
        Me.lblCodigo.Location = New System.Drawing.Point(458, 219)
        Me.lblCodigo.Name = "lblCodigo"
        Me.lblCodigo.Size = New System.Drawing.Size(11, 13)
        Me.lblCodigo.TabIndex = 40
        Me.lblCodigo.Text = "*"
        '
        'lblHoraEnvio
        '
        Me.lblHoraEnvio.AutoSize = True
        Me.lblHoraEnvio.Location = New System.Drawing.Point(669, 190)
        Me.lblHoraEnvio.Name = "lblHoraEnvio"
        Me.lblHoraEnvio.Size = New System.Drawing.Size(11, 13)
        Me.lblHoraEnvio.TabIndex = 41
        Me.lblHoraEnvio.Text = "*"
        '
        'txtCor
        '
        Me.txtCor.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtCor.Location = New System.Drawing.Point(633, 212)
        Me.txtCor.Name = "txtCor"
        Me.txtCor.Size = New System.Drawing.Size(130, 20)
        Me.txtCor.TabIndex = 11
        '
        'txtCaixa
        '
        Me.txtCaixa.Location = New System.Drawing.Point(633, 236)
        Me.txtCaixa.Name = "txtCaixa"
        Me.txtCaixa.Size = New System.Drawing.Size(130, 20)
        Me.txtCaixa.TabIndex = 13
        '
        'txtMaquina
        '
        Me.txtMaquina.Location = New System.Drawing.Point(461, 236)
        Me.txtMaquina.Name = "txtMaquina"
        Me.txtMaquina.Size = New System.Drawing.Size(96, 20)
        Me.txtMaquina.TabIndex = 12
        '
        'txtObservacao
        '
        Me.txtObservacao.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtObservacao.Location = New System.Drawing.Point(461, 262)
        Me.txtObservacao.MaxLength = 200
        Me.txtObservacao.Multiline = True
        Me.txtObservacao.Name = "txtObservacao"
        Me.txtObservacao.Size = New System.Drawing.Size(302, 34)
        Me.txtObservacao.TabIndex = 14
        '
        'txtEnviado
        '
        Me.txtEnviado.Location = New System.Drawing.Point(461, 302)
        Me.txtEnviado.Name = "txtEnviado"
        Me.txtEnviado.Size = New System.Drawing.Size(141, 20)
        Me.txtEnviado.TabIndex = 15
        '
        'rbLiberado
        '
        Me.rbLiberado.AutoSize = True
        Me.rbLiberado.Location = New System.Drawing.Point(7, 15)
        Me.rbLiberado.Name = "rbLiberado"
        Me.rbLiberado.Size = New System.Drawing.Size(14, 13)
        Me.rbLiberado.TabIndex = 3
        Me.rbLiberado.TabStop = True
        Me.rbLiberado.UseVisualStyleBackColor = True
        '
        'rbNLiberada
        '
        Me.rbNLiberada.AutoSize = True
        Me.rbNLiberada.Location = New System.Drawing.Point(7, 35)
        Me.rbNLiberada.Name = "rbNLiberada"
        Me.rbNLiberada.Size = New System.Drawing.Size(14, 13)
        Me.rbNLiberada.TabIndex = 4
        Me.rbNLiberada.TabStop = True
        Me.rbNLiberada.UseVisualStyleBackColor = True
        '
        'rbIniProducao
        '
        Me.rbIniProducao.AutoSize = True
        Me.rbIniProducao.Location = New System.Drawing.Point(10, 16)
        Me.rbIniProducao.Name = "rbIniProducao"
        Me.rbIniProducao.Size = New System.Drawing.Size(14, 13)
        Me.rbIniProducao.TabIndex = 6
        Me.rbIniProducao.TabStop = True
        Me.rbIniProducao.UseVisualStyleBackColor = True
        '
        'rbMolde
        '
        Me.rbMolde.AutoSize = True
        Me.rbMolde.Location = New System.Drawing.Point(40, 15)
        Me.rbMolde.Name = "rbMolde"
        Me.rbMolde.Size = New System.Drawing.Size(14, 13)
        Me.rbMolde.TabIndex = 6
        Me.rbMolde.TabStop = True
        Me.rbMolde.UseVisualStyleBackColor = True
        '
        'rbTrocaOP
        '
        Me.rbTrocaOP.AutoSize = True
        Me.rbTrocaOP.Location = New System.Drawing.Point(10, 40)
        Me.rbTrocaOP.Name = "rbTrocaOP"
        Me.rbTrocaOP.Size = New System.Drawing.Size(14, 13)
        Me.rbTrocaOP.TabIndex = 7
        Me.rbTrocaOP.TabStop = True
        Me.rbTrocaOP.UseVisualStyleBackColor = True
        '
        'rbOutro
        '
        Me.rbOutro.AutoSize = True
        Me.rbOutro.Location = New System.Drawing.Point(40, 40)
        Me.rbOutro.Name = "rbOutro"
        Me.rbOutro.Size = New System.Drawing.Size(14, 13)
        Me.rbOutro.TabIndex = 8
        Me.rbOutro.TabStop = True
        Me.rbOutro.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.rbLiberado)
        Me.GroupBox1.Controls.Add(Me.rbNLiberada)
        Me.GroupBox1.Location = New System.Drawing.Point(144, 197)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(27, 58)
        Me.GroupBox1.TabIndex = 3
        Me.GroupBox1.TabStop = False
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(24, 341)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(828, 150)
        Me.DataGridView1.TabIndex = 54
        '
        'txtStatus
        '
        Me.txtStatus.Location = New System.Drawing.Point(200, 217)
        Me.txtStatus.MaxLength = 12
        Me.txtStatus.Name = "txtStatus"
        Me.txtStatus.Size = New System.Drawing.Size(100, 20)
        Me.txtStatus.TabIndex = 55
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(382, 78)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(49, 13)
        Me.Label24.TabIndex = 56
        Me.Label24.Text = "MOTIVO"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.rbIniProducao)
        Me.GroupBox2.Controls.Add(Me.rbTrocaOP)
        Me.GroupBox2.Controls.Add(Me.rbOutro)
        Me.GroupBox2.Controls.Add(Me.rbMolde)
        Me.GroupBox2.Location = New System.Drawing.Point(477, 80)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(62, 61)
        Me.GroupBox2.TabIndex = 5
        Me.GroupBox2.TabStop = False
        '
        'lblMotivo
        '
        Me.lblMotivo.AutoSize = True
        Me.lblMotivo.Location = New System.Drawing.Point(710, 94)
        Me.lblMotivo.Name = "lblMotivo"
        Me.lblMotivo.Size = New System.Drawing.Size(11, 13)
        Me.lblMotivo.TabIndex = 59
        Me.lblMotivo.Text = "*"
        '
        'frmLiberacao
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(886, 503)
        Me.Controls.Add(Me.lblMotivo)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.Label24)
        Me.Controls.Add(Me.txtStatus)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.txtEnviado)
        Me.Controls.Add(Me.txtObservacao)
        Me.Controls.Add(Me.txtMaquina)
        Me.Controls.Add(Me.txtCaixa)
        Me.Controls.Add(Me.txtCor)
        Me.Controls.Add(Me.lblHoraEnvio)
        Me.Controls.Add(Me.lblCodigo)
        Me.Controls.Add(Me.lblProduto)
        Me.Controls.Add(Me.lblDataEnvio)
        Me.Controls.Add(Me.txtOP)
        Me.Controls.Add(Me.txtOutro)
        Me.Controls.Add(Me.lblHoraverificacao)
        Me.Controls.Add(Me.lblDataverificacao)
        Me.Controls.Add(Me.txtRealizadopor)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Label23)
        Me.Controls.Add(Me.Label21)
        Me.Controls.Add(Me.Label20)
        Me.Controls.Add(Me.Label19)
        Me.Controls.Add(Me.Label18)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.lblTitulo)
        Me.Controls.Add(Me.ShapeContainer1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.KeyPreview = True
        Me.MaximizeBox = False
        Me.MaximumSize = New System.Drawing.Size(892, 541)
        Me.Name = "frmLiberacao"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Liberação"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblTitulo As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents ShapeContainer1 As Microsoft.VisualBasic.PowerPacks.ShapeContainer
    Friend WithEvents LineShape1 As Microsoft.VisualBasic.PowerPacks.LineShape
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents txtRealizadopor As System.Windows.Forms.TextBox
    Friend WithEvents lblDataverificacao As System.Windows.Forms.Label
    Friend WithEvents lblHoraverificacao As System.Windows.Forms.Label
    Friend WithEvents txtOutro As System.Windows.Forms.TextBox
    Friend WithEvents txtOP As System.Windows.Forms.TextBox
    Friend WithEvents lblDataEnvio As System.Windows.Forms.Label
    Friend WithEvents lblProduto As System.Windows.Forms.Label
    Friend WithEvents lblCodigo As System.Windows.Forms.Label
    Friend WithEvents lblHoraEnvio As System.Windows.Forms.Label
    Friend WithEvents txtCor As System.Windows.Forms.TextBox
    Friend WithEvents txtCaixa As System.Windows.Forms.TextBox
    Friend WithEvents txtMaquina As System.Windows.Forms.TextBox
    Friend WithEvents txtObservacao As System.Windows.Forms.TextBox
    Friend WithEvents txtEnviado As System.Windows.Forms.TextBox
    Friend WithEvents rbLiberado As System.Windows.Forms.RadioButton
    Friend WithEvents rbNLiberada As System.Windows.Forms.RadioButton
    Friend WithEvents rbIniProducao As System.Windows.Forms.RadioButton
    Friend WithEvents rbMolde As System.Windows.Forms.RadioButton
    Friend WithEvents rbTrocaOP As System.Windows.Forms.RadioButton
    Friend WithEvents rbOutro As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents txtStatus As System.Windows.Forms.TextBox
    Friend WithEvents LineShape2 As Microsoft.VisualBasic.PowerPacks.LineShape
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents lblMotivo As System.Windows.Forms.Label

End Class
