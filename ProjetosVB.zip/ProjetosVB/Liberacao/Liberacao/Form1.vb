﻿Imports System.Data.OleDb
Public Class frmLiberacao
    Dim da As OleDbDataAdapter
    Dim conn As OleDbConnection
    Dim cb As OleDbCommandBuilder
    Dim ds2 As New DataSet
    Private Sub frmLiberacao_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        conn = New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=E:\ProjetosVB\Recebimento 2013\BDLiberacao.accdb;Persist Security Info=False;")
        Dim sel As String = "SELECT top 100 * FROM tblLiberacao where OP > 0  order by OP desc"
        da = New OleDbDataAdapter(sel, conn)
        cb = New OleDbCommandBuilder(da)
        da.MissingSchemaAction = MissingSchemaAction.AddWithKey
        da.Fill(ds2, "tblLiberacao")
        Me.DataGridView1.DataSource = ds2
        Me.DataGridView1.DataMember = "tblLiberacao"
    End Sub
    'Enter com a função de TAB, Altere a propriedade KeyPreview do formulário para True;
    Private Sub frmLiberacao_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles MyBase.KeyPress
        If e.KeyChar = Convert.ToChar(13) Then
            e.Handled = True
            SendKeys.Send("{TAB}")
        End If
    End Sub
    Private Sub rbLiberado_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles rbLiberado.CheckedChanged
        If rbLiberado.Checked = True Then
            txtStatus.Text = "Liberado"
        Else
            txtStatus.Text = "Não Liberado"
        End If
    End Sub
    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        If rbLiberado.Checked = False And rbNLiberada.Checked = False Then
            MsgBox("Selecione um Status", , "Status da Máquina")
        End If
    End Sub
    Private Sub rbIniProducao_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles rbIniProducao.CheckedChanged
        If rbIniProducao.Checked = True Then
            lblMotivo.Text = "Inicio de Produção"
        End If
    End Sub
    Private Sub rbMolde_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles rbMolde.CheckedChanged
        If rbMolde.Checked = True Then
            lblMotivo.Text = "Recolocação de Molde"
        End If
    End Sub
    Private Sub rbTrocaOP_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles rbTrocaOP.CheckedChanged
        If rbTrocaOP.Checked = True Then
            lblMotivo.Text = "Troca de OP"
        End If
    End Sub
    Private Sub rbOutro_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles rbOutro.CheckedChanged
        If rbOutro.Checked = True Then
            lblMotivo.Text = ""
            txtOutro.Enabled = True
        Else
            txtOutro.Text = ""
            txtOutro.Enabled = False
        End If
    End Sub
    Private Sub txtRealizadopor_TextChanged(sender As System.Object, e As System.EventArgs) Handles txtRealizadopor.TextChanged
    End Sub
End Class
