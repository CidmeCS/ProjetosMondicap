﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Enviar_Outlook
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btEnviar = New System.Windows.Forms.Button()
        Me.txtPara = New System.Windows.Forms.TextBox()
        Me.lblPara = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtAssunto = New System.Windows.Forms.TextBox()
        Me.lblMensagem = New System.Windows.Forms.Label()
        Me.txtMensagem = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'btEnviar
        '
        Me.btEnviar.Location = New System.Drawing.Point(12, 227)
        Me.btEnviar.Name = "btEnviar"
        Me.btEnviar.Size = New System.Drawing.Size(75, 23)
        Me.btEnviar.TabIndex = 0
        Me.btEnviar.Text = "Enviar"
        Me.btEnviar.UseVisualStyleBackColor = True
        '
        'txtPara
        '
        Me.txtPara.Location = New System.Drawing.Point(66, 50)
        Me.txtPara.Name = "txtPara"
        Me.txtPara.Size = New System.Drawing.Size(197, 20)
        Me.txtPara.TabIndex = 1
        '
        'lblPara
        '
        Me.lblPara.AutoSize = True
        Me.lblPara.Location = New System.Drawing.Point(13, 53)
        Me.lblPara.Name = "lblPara"
        Me.lblPara.Size = New System.Drawing.Size(29, 13)
        Me.lblPara.TabIndex = 2
        Me.lblPara.Text = "Para"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(13, 82)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(45, 13)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "Assunto"
        '
        'txtAssunto
        '
        Me.txtAssunto.Location = New System.Drawing.Point(66, 79)
        Me.txtAssunto.Name = "txtAssunto"
        Me.txtAssunto.Size = New System.Drawing.Size(197, 20)
        Me.txtAssunto.TabIndex = 3
        '
        'lblMensagem
        '
        Me.lblMensagem.AutoSize = True
        Me.lblMensagem.Location = New System.Drawing.Point(16, 127)
        Me.lblMensagem.Name = "lblMensagem"
        Me.lblMensagem.Size = New System.Drawing.Size(59, 13)
        Me.lblMensagem.TabIndex = 5
        Me.lblMensagem.Text = "Mensagem"
        '
        'txtMensagem
        '
        Me.txtMensagem.Location = New System.Drawing.Point(66, 143)
        Me.txtMensagem.Multiline = True
        Me.txtMensagem.Name = "txtMensagem"
        Me.txtMensagem.Size = New System.Drawing.Size(197, 61)
        Me.txtMensagem.TabIndex = 6
        '
        'Enviar_Outlook
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(284, 262)
        Me.Controls.Add(Me.txtMensagem)
        Me.Controls.Add(Me.lblMensagem)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtAssunto)
        Me.Controls.Add(Me.lblPara)
        Me.Controls.Add(Me.txtPara)
        Me.Controls.Add(Me.btEnviar)
        Me.Name = "Enviar_Outlook"
        Me.Text = "Enviar Outlook"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btEnviar As System.Windows.Forms.Button
    Friend WithEvents txtPara As System.Windows.Forms.TextBox
    Friend WithEvents lblPara As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtAssunto As System.Windows.Forms.TextBox
    Friend WithEvents lblMensagem As System.Windows.Forms.Label
    Friend WithEvents txtMensagem As System.Windows.Forms.TextBox

End Class
