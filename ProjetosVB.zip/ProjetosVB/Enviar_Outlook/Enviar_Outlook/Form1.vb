﻿Imports Microsoft.Office.Interop
Public Class Enviar_Outlook
    Dim OutlookMessage As Outlook.MailItem
    Dim AppOutlook As New Outlook.Application
    Private Sub btEnviar_Click(sender As System.Object, e As System.EventArgs) Handles btEnviar.Click
        Try
            OutlookMessage = AppOutlook.CreateItem(Outlook.OlItemType.olMailItem)
            'Dim Recipents As Outlook.Recipients = OutlookMessage.Recipients
            OutlookMessage.To = txtPara.Text
            'Recipents.Add("myemail@hotmail.com")
            OutlookMessage.Subject = "Pedido: " & Today & " - " & TimeString & txtAssunto.Text
            OutlookMessage.Body = "Testing outlook Mail" & txtMensagem.Text
            OutlookMessage.BodyFormat = Outlook.OlBodyFormat.olFormatHTML
            'OutlookMessage.Send()
            OutlookMessage.Display()
            OutlookMessage.Save()
        Catch ex As Exception
            MessageBox.Show("Mail could not be sent") 'if you dont want this message, simply delete this line 
        Finally
            OutlookMessage = Nothing
            AppOutlook = Nothing
        End Try
    End Sub
End Class
