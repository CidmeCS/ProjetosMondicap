﻿Imports System.Data.OleDb
Imports System
Imports System.Drawing
Imports System.Windows.Forms
Public Class FromTo2
    Dim ds1 As New DataSet
    Dim ds2 As New DataSet
    Dim ds3 As New DataSet
    Private Sub FromTo2_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Shown
        Call Teste_Aberto()
        Call PriMeiro_Passo()
    End Sub
    Sub PriMeiro_Passo() Handles MyBase.Shown
        Dim _conn As String
        _conn = ("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=E:\ProjetosVB\Recebimento 2013\Consulta_OP.xlsx;Extended Properties=Excel 8.0")
        Dim _connection As OleDbConnection = New OleDbConnection(_conn)
        Dim da As OleDbDataAdapter = New OleDbDataAdapter()
        Dim _command As OleDbCommand = New OleDbCommand()
        _command.Connection = _connection
        _command.CommandText = "SELECT top 100 * FROM [tblOP$] where OP > 0 order by OP desc "
        da.SelectCommand = _command
        Try
            da.Fill(ds1, "tblOP")
            'Me.DataGridView1.DataSource = ds1
            'Me.DataGridView1.DataMember = "tblOP"
            Call segundo_Passo()
        Catch e1 As Exception
            lblMensagem.Text = "Falha"
            MessageBox.Show("Import Failed, correct Column name in the sheet!")
        End Try
    End Sub
    Dim da As OleDbDataAdapter
    Dim conn As OleDbConnection
    Dim cb As OleDbCommandBuilder
    Sub segundo_Passo() Handles MyBase.Shown
        conn = New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=E:\ProjetosVB\Recebimento 2013\Consulta_OP.accdb;Persist Security Info=False;")
        Dim sel As String = "SELECT top 100 * FROM tblOP where OP > 0  order by OP desc "
        da = New OleDbDataAdapter(sel, conn)
        cb = New OleDbCommandBuilder(da)
        da.MissingSchemaAction = MissingSchemaAction.AddWithKey
        da.Fill(ds2, "tblOP")
        ' Me.DataGridView1.DataSource = ds2
        'Me.DataGridView1.DataMember = "tblOP"
        Call Terceiro_Passo()
    End Sub
    Sub Terceiro_Passo() Handles MyBase.Shown
        For Each dr As DataRow In ds1.Tables(0).Rows
            Dim expression As String
            expression = "OP = " + CType(dr.Item(0), Integer).ToString
            Dim drs() As DataRow = ds2.Tables(0).Select(expression)
            If (drs.Length = 1) Then
                For i As Integer = 1 To ds2.Tables(0).Columns.Count - 1
                    drs(0).Item(i) = dr.Item(i)
                Next
            Else
                Dim drnew As DataRow = ds2.Tables(0).NewRow
                For i As Integer = 0 To ds2.Tables(0).Columns.Count - 1
                    drnew.Item(i) = dr.Item(i)
                Next
                ds2.Tables(0).Rows.Add(drnew)
            End If
        Next
        'Me.DataGridView1.DataSource = ds2
        ' Me.DataGridView1.DataMember = "tblOP"
        da.Update(ds2.Tables(0))
        Call Quarto_Passo()
    End Sub
    Dim da2 As OleDbDataAdapter
    Dim conn2 As OleDbConnection
    Dim cb2 As OleDbCommandBuilder
    Sub Quarto_Passo() Handles MyBase.Shown
        conn2 = New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=E:\ProjetosVB\Recebimento 2013\Consulta_OP.accdb;Persist Security Info=False;")
        Dim sel2 As String = "SELECT top 100 * FROM tblOP where OP > 0 order by OP Desc"
        da2 = New OleDbDataAdapter(sel2, conn2)
        cb2 = New OleDbCommandBuilder(da2)
        da2.MissingSchemaAction = MissingSchemaAction.AddWithKey
        da2.Fill(ds3, "tblOP")
        DataGridView1.DataSource = ds3
        DataGridView1.DataMember = "tblOP"
        lblMensagem.Text = "Mensagem: A Importação dos dados está Completa!"
        btFechar.Focus()
    End Sub

    Private Sub btFechar_Click(sender As System.Object, e As System.EventArgs) Handles btFechar.Click
        Close()
    End Sub
    Sub Teste_Aberto()
        Dim Access As Boolean
        Dim Excel As Boolean
        Excel = Test("E:\ProjetosVB\Recebimento 2013\Consulta_OP.xlsx")
        Access = Test("E:\ProjetosVB\Recebimento 2013\Consulta_OP.accdb")
        If Excel = True Then
            MsgBox("O Arquivo Excel de importação está aberto, Feche-o para para continuar")
            Close()
        ElseIf Access = True Then
            MsgBox("O Arquivo Access de importação está aberto, Feche-o para para continuar")
            Close()
        Else
        End If
    End Sub
    Function Test(ByVal pathfile As String) As Boolean
        Dim ff As Integer
        If System.IO.File.Exists(pathfile) Then
            Try
                ff = FreeFile()
                Microsoft.VisualBasic.FileOpen(ff, pathfile, OpenMode.Binary, OpenAccess.Read, OpenShare.LockReadWrite)
                Return False
            Catch
                Return True
            Finally
                FileClose(ff)
            End Try
            Return True
        Else
        End If
        Return True
    End Function
End Class
